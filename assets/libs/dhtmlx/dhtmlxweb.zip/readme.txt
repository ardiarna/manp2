To change your skin please follow the link:
https://dhtmlx.com/docs/products/skinBuilder/index.shtml#d6dbb25aff